#include <stdio.h>    /* entrées sorties */
#include <unistd.h>   /* pimitives de base : fork, ...*/
#include <stdlib.h>   /* exit */
#include <fcntl.h>    /* opérations sur les fichiers */

/* Traiter les erreurs d'appels de primitives */
void traitement_erreur(int primitive) {
  if (primitive < 0) {
    perror("Erreur execution\n");
    exit(1);
  }
}

int main (int argc, char** argv) {
  int pipe1, pipe2, retour1, retour2, redirec1, redirec2, redirec3, redirec4, exec1, exec2, exec3;

  /* Initialisation des pipes */
  int p1[2];
  int p2[2];

  /* Création du 1er pipe */
  pipe1 = pipe(p1);
  traitement_erreur(pipe1);

  /* Création du 1er fils */
  retour1 = fork();
  traitement_erreur(retour1);

  if (retour1 == 0) { /* 1er fils */

    close(p1[0]); /* le fils est en écriture, on ferme donc la lecture */

    redirec1 = dup2(p1[1], 1); /* on redirige ce que va écrire le fils */
    traitement_erreur(redirec1);

    close(p1[1]); /* on ferme une fois la redirection effectuée */

    /* Création du 2ème pipe */
    pipe2 = pipe(p2);
    traitement_erreur(pipe2);

    retour2 = fork();
    traitement_erreur(retour2);

    if (retour2 == 0) { /* 2ème fils */

      close(p2[0]);

      redirec2 = dup2(p2[1], 1);
      traitement_erreur(redirec2);

      close(p2[1]);

      exec1 = execlp("who", "who", NULL);
      traitement_erreur(exec1);

    } else {

        close(p2[1]); /* le fils est en lecture, on ferme l'écriture */

        redirec3 = dup2(p2[0], 0); /* on redirige ce que va lire le fils */
        traitement_erreur(redirec3);

        close(p2[0]);

        exec2 = execlp("grep", "grep", argv[1], NULL);
        traitement_erreur(exec2);
      }

  } else {

      close(p1[1]);

      redirec4 = dup2(p1[0], 0); /* on redirige ce que va lire le fils */
      traitement_erreur(redirec4);

      close(p1[0]);

      exec3 = execlp("wc", "wc", "-l", NULL);
      traitement_erreur(exec3);

  }

  return EXIT_SUCCESS;
}
