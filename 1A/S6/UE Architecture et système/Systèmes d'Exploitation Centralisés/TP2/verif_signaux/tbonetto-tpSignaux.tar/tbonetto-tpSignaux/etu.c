#include <stdio.h> /* entrées / sorties */
#include <unistd.h> /* primitives de base : fork , ...*/
#include <stdlib.h> /* exit */
#include <signal.h>   /* traitement des signaux */

/* Traitant des signaux SIGUSR1 et SIGUSR2 */
void handler_SIGUSR(int signal_num) {
    printf("\n Reception %d \n", signal_num);
    return;
}

int main(void) {

    sigset_t ens_signaux1, ens_signaux2;

    /* initialiser à vide ens_signaux1 */
    sigemptyset(&ens_signaux1);
    /* initialiser à vide ens_signaux2 */
    sigemptyset(&ens_signaux2);

    /* ajouter SIGUSR1 à ens_signaux1 */
    sigaddset(&ens_signaux1, SIGUSR1);
    /* ajouter SIGINT à ens_signaux2 */
    sigaddset(&ens_signaux2, SIGINT);

    /* associer traitant SIGUSR à SIGUSR1 */
    signal(SIGUSR1, handler_SIGUSR);
    /* associer traitant SIGUSR à SIGUSR2 */
    signal(SIGUSR2, handler_SIGUSR);

    printf("Je suis le processus principal de pid %d\n", getpid());

    /* période durant laquelle on ne veut pas être embêté par SIGUSR1 */
    printf("\nProcessus de pid %d : Je masque SIGUSR1\n", getpid());
    /* masquer les signaux définis dans ens_signaux1 : SIGUSR1 */
    sigprocmask(SIG_BLOCK, &ens_signaux1, NULL) ;

    /* période durant laquelle on ne veut pas être embêté par SIGINT */
    printf("\nProcessus de pid %d : Je masque SIGINT\n", getpid());
    /* masquer les signaux définis dans ens_signaux2 : SIGINT */
    sigprocmask(SIG_BLOCK, &ens_signaux2, NULL) ;

    /* envoie de 2 signaux SIGUSR1 */
    kill(getpid(), SIGUSR1);
    kill(getpid(), SIGUSR1);

    /* attend 5s */
    sleep(5);

    /* envoie de 2 signaux SIGUSR2 */
    kill(getpid(), SIGUSR2);
    kill(getpid(), SIGUSR2);

    /* démasquer les signaux définis dans ens_signaux1 : SIGUSR1 */
    sigprocmask(SIG_UNBLOCK, &ens_signaux1, NULL) ;

    /* on attend 10s */
    sleep(10);

    /* démasquer les signaux définis dans ens_signaux2 : SIGINT */
    sigprocmask(SIG_UNBLOCK, &ens_signaux2, NULL) ;

    /* message de terminaison */
    printf("\nSalut terminaison du programme\n");

    return EXIT_SUCCESS;
}
