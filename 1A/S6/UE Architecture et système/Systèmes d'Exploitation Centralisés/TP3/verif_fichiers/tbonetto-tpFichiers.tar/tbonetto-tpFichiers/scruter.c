/* Exemple d'illustration des primitives Unix : Un père et ses fils */
/* Fichiers : lecture partagée entre père et fils avec ouverture unique */

#include <stdio.h>    /* entrées sorties */
#include <unistd.h>   /* pimitives de base : fork, ...*/
#include <stdlib.h>   /* exit */
#include <sys/wait.h> /* wait */
#include <string.h>   /* opérations sur les chaines */
#include <fcntl.h>    /* opérations sur les fichiers */

void traitement_erreur(int primitive) {
  if (primitive < 0) {
    perror("Erreur execution\n");
    exit(1);
  }
}

int main() {

    int retour, desc_fic, ecriture, fermeture, debut_fic, k;
    int duree_sommeil = 1;

    char fichier[] = "temp.txt";

    retour = fork();
    /* traiter systématiquement les retours d'erreur des appels */
    traitement_erreur(retour);


    /* fils */
    if (retour == 0) {

        /* ouverture du fichier en écriture */
        desc_fic = open(fichier, O_WRONLY | O_CREAT | O_TRUNC, 0640);
        traitement_erreur(desc_fic);


        /* écriture des entiers de 1 à 30 */
        for (int ifor = 1; ifor <= 30; ifor++) {
            sleep(duree_sommeil);
            ecriture = write(desc_fic, &ifor, sizeof(int));
            traitement_erreur(ecriture);
            printf("i = %d\n",ifor);

            /* revenir au début du ficher tous les 10 entiers */
            if (ifor % 10 == 0) {
              debut_fic = lseek(desc_fic, 0, SEEK_SET);
              traitement_erreur(debut_fic);
            }
        }

        /* fermeture du ficher "temp.txt" */
        fermeture = close(desc_fic);
        traitement_erreur(retour);

        /* Important : terminer un processus par exit */
        exit(EXIT_SUCCESS);
    }

    /* frère */
    if (retour > 0) {

        /* ouverture du fichier en écriture */
        desc_fic = open(fichier, O_RDONLY | O_CREAT, 0640);
        traitement_erreur(desc_fic);


        /* lecture des entiers dans le fichier "temp.txt" */
        for (int ifor = 1; ifor <= 3; ifor++) {
            sleep(duree_sommeil*11);
            while(read(desc_fic, &k, sizeof(int)) > 0) {
              printf("%d\n", k);
            }

            /* revenir au début du ficher */
            debut_fic = lseek(desc_fic, 0, SEEK_SET);
            traitement_erreur(debut_fic);
          }

          /* fermeture du ficher "temp.txt" */
          fermeture = close(desc_fic);
          traitement_erreur(retour);

          /* Important : terminer un processus par exit */
          exit(EXIT_SUCCESS);
        }

    printf("Processus Principal termine\n");
    return EXIT_SUCCESS;
}
