#include <stdio.h>    /* entrées sorties */
#include <unistd.h>   /* pimitives de base : fork, ...*/
#include <stdlib.h>   /* exit */
#include <sys/wait.h> /* wait */
#include <string.h>   /* opérations sur les chaines */
#include <fcntl.h>    /* opérations sur les fichiers */

#define BUFSIZE 4096

/* Traiter les erreurs d'appels de primitives */
void traitement_erreur(int primitive) {
  if (primitive < 0) {
    perror("Erreur execution\n");
    exit(1);
  }
}

int main(int argc, char** argv) {
    int desc_fic1, desc_fic2, ecriture, fermer_source, fermer_destination;
    char buffer[BUFSIZE];     /* buffer de lecture */

    /* Initialisation du buffer */
    bzero(buffer, BUFSIZE);

    /* Ouverture du fichier source en lecture */
    desc_fic1 = open(argv[1], O_RDONLY);
    /*  Traiter systématiquement les retours d'erreur des appels */
    traitement_erreur(desc_fic1);

    /* Ouverture du fichier destination en ecriture, avec autorisations rw- -r- ---*/
    /* avec création si le fichier n'existe pas : O_CREAT */
    /* avec vidange (raz du contenu) si le fichier existe: O_TRUNC */
    desc_fic2 = open(argv[2], O_WRONLY | O_CREAT | O_TRUNC, 0640);
    /*  Traiter systématiquement les retours d'erreur des appels */
    traitement_erreur(desc_fic2);

    /* Lecture du fichier source */
    while (read(desc_fic1, buffer, BUFSIZE) > 0) {
        /* Ecriture dans le fichier destination */
        ecriture = write(desc_fic2, buffer, strlen(buffer));
        /*  Traiter systématiquement les retours d'erreur des appels */
        traitement_erreur(ecriture);
        /* Réinitialisation du buffer */
        bzero(buffer, BUFSIZE);
    }

    /* Fermeture du fichier source */
    fermer_source = close(desc_fic1);
    /*  Traiter systématiquement les retours d'erreur des appels */
    traitement_erreur(fermer_source);

    /* Fermeture du fichier destination */
    fermer_destination = close(desc_fic2);
    /*  Traiter systématiquement les retours d'erreur des appels */
    traitement_erreur(fermer_destination);

    printf("Processus Principal termine\n");
    return EXIT_SUCCESS;
}
