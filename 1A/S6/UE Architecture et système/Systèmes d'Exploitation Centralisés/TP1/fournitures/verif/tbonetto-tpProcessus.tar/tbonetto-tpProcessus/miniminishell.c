# include <stdio.h>
# include <unistd.h>
# include <stdlib.h>
# include <sys/wait.h>
# include <string.h>

int main ( int argc , char * argv []) {
  pid_t idFils, pidFils ;
  int codeTerm;
  while(1) {

    pidFils = fork ();

    if ( pidFils == -1) {
      printf (" Erreur fork \n");
      exit(1);
    }
    if (pidFils == 0) { /* fils */
      char buf[30]; /* contient la commande saisie au clavier */
      int ret; /* valeur de retour de scanf */
      printf("Entrer le nom d'une commande (sans paramètre) de moins de 30 caractères");
      printf(">>>");

      /* Lire la commande entrée au clavier */
      ret = scanf("%s", buf);

      // Détection du exit
      if (strcmp(buf,"exit") == 0 || ret == EOF) {
        exit(3);
      }

      /* Execution de la commande */
      char args[36] = "/bin/";
      strcat(args,buf);
      execl(args,"",NULL);

      /* Message en cas d'erreur */
      perror("Erreur execution");
      exit(1);
    }

    else { /* père */
      idFils = wait(&codeTerm);
      fflush(stdout);
      if(idFils == -1) {
        perror("wait ");
        exit(2);

      }

      if (WEXITSTATUS(codeTerm) == 1) {
          printf("ECHEC la commande ne s'est pas exécutée.");
      } else if (WEXITSTATUS(codeTerm) == 3) {
          printf("Salut à bientôt !");
          exit(EXIT_SUCCESS);
      } else {
          printf("SUCCES la commande s'est exécutée.");
      }
      fflush(stdout);

    }
  }
}
