#include <stdio.h> /* entrées / sorties */
#include <unistd.h> /* primitives de base : fork , ...*/
#include <stdlib.h> /* exit */
#include <signal.h>   /* traitement des signaux */
#include <string.h>
#include <sys/wait.h>
#include <limits.h>
#include "listeProcessus.h"

int estPresent(listeProcessus *liste, int id) {
  if (liste->taille < 1) {
    return 1;
  } else {
		  for (int i = 0; i <= liste->taille; i++) {
			  if ((&(liste->listeProc[i]))->identifiant == id) {
				  return 0;
			}
		}
    return 1;
	}
}

int pidProcessus(listeProcessus *liste, int id) {
  if (liste) {
		int i = 0;
		while ((&(liste->listeProc[i]))->identifiant != id) {
			i++;
		}
		return (&(liste->listeProc[i]))->pid;
	} else {
		return -1;
	}
}

int ajouterProcessus(listeProcessus *liste, char *cmd, pid_t pid) {
  int n = liste->taille;
  processus *listeProc = realloc(liste->listeProc, (n + 1)*sizeof(processus)); /* on réalloue une adresse mémoire plus grande de 1 éléments */
  if (listeProc) {
    (&(listeProc[n]))->pid = pid;
    (&(listeProc[n]))->etat = Actif;
    (&(listeProc[n]))->cmd = malloc(sizeof(char)); /* allouer la mémoire */
    (&(listeProc[n]))->cmd = strcpy((&(listeProc[n]))->cmd, cmd); /* on copie à l'adresse mémoire la commande (type str) */
    if (n == 0) {
      (&(listeProc[n]))->identifiant = n+1;
    } else {
      (&(listeProc[n]))->identifiant = (&(listeProc[n-1]))->identifiant+1;
    }
    liste->listeProc = listeProc;
    liste->taille = n + 1;
    return 0;
  } else {
    return 1;
  }
}

int retirerProcessus(listeProcessus *liste, pid_t pid) {
	if (liste->taille >= 1) {
		int nb = liste->taille - 1;
		processus *lesProcessus = calloc(nb, sizeof(processus));
		processus *curseur = calloc(nb + 1, sizeof(processus));
		curseur = liste->listeProc;

		if (curseur) {
			int j = 0;
			for (int i = 0; i < nb + 1; i++) {
				if ((&(curseur[i]))->pid == pid) {
					char *nom = (&(curseur[i]))->cmd;
					j = i;
				} else {
					(&(lesProcessus[j]))->cmd = (&(curseur[i]))->cmd;
					(&(lesProcessus[j]))->pid = (&(curseur[i]))->pid;
					(&(lesProcessus[j]))->etat = (&(curseur[i]))->etat;
					(&(lesProcessus[j]))->identifiant = (&(curseur[i]))->identifiant;
					j++;
				}
			}
			liste->listeProc = lesProcessus;
			liste->taille = nb;
			return 0;
		}
	}
	return 1;
}

void modifierEtat(listeProcessus *liste, pid_t pid, Etats etat) {
  if (liste) {
		for (int i = 0; i <= liste->taille; i++) {
			if ((&(liste->listeProc[i]))->pid == pid) {
				((&(liste->listeProc[i]))->etat) = etat;
			}
		}
	}
}

void afficherProcessus(listeProcessus *liste) {
  if (liste) {
    int n = liste->taille;
    if (n > 0) { /* si pas de processus dans la liste on affiche rien  */

    }
		for (int i = 0; i < liste->taille; i++) {
      printf("Proc : %d, PID : %d, CMD : %s,",(&(liste->listeProc[i]))->identifiant,(&(liste->listeProc[i]))->pid, (&(liste->listeProc[i]))->cmd);
			if (((&(liste->listeProc[i]))->etat) == Actif) {
				printf(" Etat : Actif\n");
			} else {
				printf(" Etat : Suspendu\n");
			}
		}
	}
}
