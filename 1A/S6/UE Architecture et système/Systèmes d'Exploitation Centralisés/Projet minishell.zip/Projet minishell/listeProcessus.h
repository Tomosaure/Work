#include <stdio.h> /* entrées / sorties */
#include <unistd.h> /* primitives de base : fork , ...*/
#include <stdlib.h> /* exit */
#include <signal.h>   /* traitement des signaux */
#include <string.h>
#include <sys/wait.h>
#include <limits.h>

#ifndef _LISTEPROCESSUS_H
#define _LISTEPROCESSUS_H

/* Etats des processus */
typedef enum Etats {Actif, Suspendu} Etats;

 /* Définition d'un processus */
struct processus {
   int identifiant; /* identifiant du processus */
   pid_t pid; /* pid du processus */
   Etats etat; /* l'état du proccessus */
   char *cmd; /* la commande du processus */
 };
 typedef struct processus processus;

/* Liste des processus */
struct listeProcessus {
  int taille; /* La taille de liste : le nombre de processus */
  processus *listeProc; /* les différents processus */
};
typedef struct listeProcessus listeProcessus;

/* Vérifier si un processus est présent dans la liste à partir de son identifiant */
int estPresent(listeProcessus *liste, int id);

/* Retourner le pid du processus à partir de son identifiant */
int pidProcessus(listeProcessus *liste, int identifiant);


/* Ajouter un processus à la liste */
int ajouterProcessus(listeProcessus *liste, char *cmd, pid_t pid);

/* Retirer un processus à la liste */
int retirerProcessus(listeProcessus *liste, pid_t pid);

/* Changer l'état d'un processus de la liste */
void modifierEtat(listeProcessus *liste, pid_t pid, Etats etat);

/* Afficher les différents processus de la liste */
void afficherProcessus(listeProcessus *liste);

 #endif
