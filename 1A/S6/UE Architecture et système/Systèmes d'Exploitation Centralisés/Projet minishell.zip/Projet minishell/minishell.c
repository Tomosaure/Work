#include <stdio.h> /* entrées / sorties */
#include <unistd.h> /* primitives de base : fork , ...*/
#include <stdlib.h> /* exit */
#include <signal.h>   /* traitement des signaux */
#include <string.h>
#include <sys/wait.h>
#include <limits.h>
#include <fcntl.h> /* les fichiers */
#include "readcmd.h"
#include "listeProcessus.h"

char cwd[PATH_MAX];
int retour;
struct cmdline *commande;
pid_t pidFils;
int codeTerm;
listeProcessus *shellProcessus; /* la structure qui va permettre de lister les procéssus */
sigset_t masque;
int redirec, pipe2;

/* Affichage du prompt du minishell */
void affichage_terminal() {
  getcwd(cwd, sizeof(cwd));
  printf("\033[32m"); /* Vert */
  printf("[");
  printf("\033[38;5;172m"); /* Orange */
  printf("tbonetto");
  printf("\033[37m"); /* Blanc */
  printf("@");
  printf("\033[38;5;153m"); /* Bleu */
  printf("mini-shell");
  printf("\033[38;5;214m"); /* Orange/Jaune */
  printf(" ~%s", cwd);
  printf("\033[32m"); /* Vet */
  printf("]");
  printf("\033[37m"); /* Blanc */
  printf("$ ");
  fflush(stdout);
}

/* Lire la commande de l'utilisateur du minishell */
void lire_commande() {
  commande = readcmd();
}

/* Traiter les erreurs d'appels de primitives */
void traitement_erreur(int primitive, char* message, int sortie) {
  if (primitive < 0) {
    perror(message);
    exit(sortie);
  }
}

/* Traitant du signal SIGCHLD */
void handler_chld(int signal_num) {
  int fils_termine, wstatus ;
  if (signal_num == SIGCHLD) {
    while ((fils_termine = (int) waitpid(-1, &wstatus, WNOHANG | WUNTRACED | WCONTINUED)) > 0) {
      if (WIFEXITED(wstatus)) { /* Le fils s'est arrêté avec exit */
        retirerProcessus(shellProcessus, fils_termine);
      } else if (WIFSIGNALED(wstatus)) { /* Le fils a recu un signal */
        retirerProcessus(shellProcessus, fils_termine);
      } else if (WIFSTOPPED(wstatus)) { /* Le fils a recu SIGSTOP */
        modifierEtat(shellProcessus, fils_termine, Suspendu);
      } else if (WIFCONTINUED(wstatus)) { /* Le fils a recu SIGCONT */
        modifierEtat(shellProcessus, fils_termine, Actif);
      }
    }
  }
}

/* Traitant du signal SIGTSTP : Ctrl-Z */
void handler_tstp(int signal_num) {
  if (pidFils > 0 && signal_num == SIGTSTP) {
    ajouterProcessus(shellProcessus, (commande->seq)[0][0], pidFils); /* on l'ajoute à la liste */
    modifierEtat(shellProcessus, pidFils, Suspendu); /* et on met à jour son état */
    kill(pidFils, SIGSTOP); /* suspendre le processus */
    printf("\nProcessus n°%d suspendu ctrl-Z\n", pidFils);
    pidFils = -1;
    fflush(stdout);
  }
}

/* Traitant du signal SIGINT : Ctrl-C */
void handler_int(int signal_num) {
  if (pidFils > 0 && signal_num == SIGINT) {
    kill(pidFils, SIGINT); /* tué le processus */
    printf("\nProcessus n°%d kill ctrl-C\n", pidFils);
    /* il n'est pas nécessaire de le retirer de la liste car celui-ci n'a jamais été ajouté */
    pidFils = -1;
    fflush(stdout);
  }
}

/* Initialiser le minishell */
void initialiser_shell() {
  signal(SIGCHLD, handler_chld); /* on associe a SIGCHLD son traitant */
  signal(SIGTSTP, handler_tstp); /* on associe a SIGTSTP son traitant */
  signal(SIGINT, handler_int); /* on associe a SIGINT son traitant */
  sigemptyset(&masque); /* on initialise le masque */
  sigaddset(&masque, SIGTSTP); /* on masque les signaux pour le minishell */
  shellProcessus = malloc(sizeof(shellProcessus)); /* on initialise la liste des processus */
  shellProcessus->taille = 0;
}

/* Executer la commande avec système de pipe ou sans s'il n'y a qu'une seule commande */
void pipeline_exec(struct cmdline *commande, int nbrCommande, int p1) {
  if ((commande->seq)[nbrCommande+1] == NULL) { /* conditions d'arrêt de la fonction récursive */
    if (p1 != 0) {
      redirec = dup2(p1,0); /* on redirige ce que va lire le fils */
      traitement_erreur(redirec, "Erreur redirection\n", 1);
      close(p1);
    }

    retour = execvp((commande->seq)[nbrCommande][0], (commande->seq)[nbrCommande]);
    traitement_erreur(retour, "Erreur execution\n", 1);

  } else {
   int p2[2];
   pipe2 = pipe(p2);
   traitement_erreur(pipe2, "Erreur pipe\n", 1);

   retour = fork();
   traitement_erreur(retour, "Erreur fork\n", 1);

   if (retour == 0) {
     close(p2[0]); /* le fils est en écriture, on ferme donc la lecture */
     redirec = dup2(p1, 0);
     traitement_erreur(redirec, "Erreur redirection\n", 1);
     close(p1);
     redirec = dup2(p2[1],1); /* on redirige ce que va écrire le fils */
     traitement_erreur(redirec, "Erreur redirection\n", 1);

     retour = execvp((commande->seq)[nbrCommande][0], (commande->seq)[nbrCommande]);
     traitement_erreur(retour, "Erreur execution\n", 1);

   } else {
     close(p2[1]); /* le fils est en lecture, on ferme l'écriture */
     pipeline_exec(commande, nbrCommande+1, p2[0]); /* appel récursif pour aller en profondeur de la commande */
   }
  }
}


/* Exécution des commandes du mini shell */
void executer_commande() {
  if (commande == NULL) {
      printf("\n--- Erreur da la fonction de saisie ou EOF - CtrlD\n");
  } else {
      if (commande->err != NULL) {
        /* tous les autres champs de commande sont NULL */
        printf("--- Erreur de structure de la commande : %s\n", commande->err);
      } else {

          if (commande->backgrounded != NULL) {
            printf("=== Commande en tache de fond\n");
          }
          /* commande->seq[i] est accessible seulement si :
          commande != NULL && command->err == NULL */
          if (commande->seq[0] == NULL) {
            printf("=== Commande vide\n");
          } else { /* Les commandes internes */
              if (!strcmp((commande->seq)[0][0], "exit")) { /* quitter le shell */
                exit(0);

              } else if (!strcmp((commande->seq)[0][0], "susp")) { /* suspendre le shell */
                printf("Je sais pas comment faire\n");

              } else if (!strcmp((commande->seq)[0][0], "cd")) {
                  retour = chdir((commande->seq)[0][1]);
                  traitement_erreur(retour, "Erreur cd\n", 1); /*  Traiter systématiquement les retours d'erreur des appels */

              } else if (!strcmp((commande->seq)[0][0], "lj")) { /* liste des processus */
                afficherProcessus(shellProcessus);

              } else if (!strcmp((commande->seq)[0][0], "sj")) { /* suspendre un processus */
                if ((commande->seq)[0][1] == NULL ) {
                  printf("Il manque l'identifiant !\n");
                } else if (estPresent(shellProcessus, atoi((commande->seq)[0][1]))){ /* robustesse */
                    printf("Processus inexistant !\n");
                } else { /* on récupère le pid via l'identifiant */
                  pid_t pidsj = pidProcessus(shellProcessus, atoi((commande->seq)[0][1])); /* atoi converti l'argument de str à int */
                  kill(pidsj, SIGSTOP);
                }

              } else if (!strcmp((commande->seq)[0][0], "fg")) { /* avant-plan */
                if ((commande->seq)[0][1] == NULL ) {
                  printf("Il manque l'identifiant !\n");
                } else if (estPresent(shellProcessus, atoi((commande->seq)[0][1]))){ /* robustesse */
                    printf("Processus inexistant !\n");
                } else {
                  pid_t pidfg = pidProcessus(shellProcessus, atoi((commande->seq)[0][1]));
                  retirerProcessus(shellProcessus, pidfg);
                  pidFils = pidfg;
                  kill(pidfg, SIGCONT); /* on relance le processus qui est en fond de tache */
                  waitpid(pidfg, NULL, WUNTRACED);
                }
              } else if (!strcmp((commande->seq)[0][0], "bg")) { /* arrière-plan */
                if ((commande->seq)[0][1] == NULL ) {
                  printf("Il manque l'identifiant !\n");
                } else if (estPresent(shellProcessus, atoi((commande->seq)[0][1]))){ /* robustesse */
                    printf("Processus inexistant !\n");
                } else {
                  pid_t pidbg = pidProcessus(shellProcessus, atoi((commande->seq)[0][1]));
                  kill(pidbg, SIGCONT);
                }
              } else {

              pidFils = fork();
              traitement_erreur(pidFils, "Erreur fork \n", 1);

              if (pidFils == 0) { /* Fils */

                /* Démasquer le Ctrl-Z */
                sigdelset(&masque, SIGTSTP);
                sigprocmask(SIG_SETMASK,&masque, 0);

                if (commande->in != NULL) {
                  printf("=== Redirection de l'entrée : %s\n", commande->in);
                  int desc_fic_src = open(commande->in, O_RDONLY);
                  traitement_erreur(desc_fic_src, "Erreur ouverture fichier en lecture\n", 1);
                  dup2(desc_fic_src,0); /* redirection de l'entrée dans le fichier */
                  close(desc_fic_src);
                }
                if (commande->out != NULL) {
                  printf("=== Redirection de la sortie : %s\n", commande->out);
                  int desc_fic_dest = open(commande->out, O_WRONLY | O_CREAT | O_TRUNC, 0640);
                  traitement_erreur(desc_fic_dest, "Erreur ouverture fichier en écriture\n", 1);
                  dup2(desc_fic_dest,1); /* redirection de la sortie dans le fichier */
                  close(desc_fic_dest);
                }

                /* Execution de la commande */
                pipeline_exec(commande, 0, 0);

              } else { /* Père */
                  if ((commande->backgrounded) == NULL) {
                    retour = (int) waitpid(pidFils, &codeTerm, WUNTRACED | WCONTINUED); /* attendre la fin d'execution du fils */
                    traitement_erreur(retour, "wait ", 2);

                  } else { /* On ajoute le processus à la liste */
                      ajouterProcessus(shellProcessus, (commande->seq)[0][0], pidFils);
                  }
                }

            }
        }
    }
  }
}

/* Exécution du mini shell */
int main() {
  initialiser_shell();
  while(1) {
    affichage_terminal();
    lire_commande();
    executer_commande();
  }
  return EXIT_SUCCESS;
}
